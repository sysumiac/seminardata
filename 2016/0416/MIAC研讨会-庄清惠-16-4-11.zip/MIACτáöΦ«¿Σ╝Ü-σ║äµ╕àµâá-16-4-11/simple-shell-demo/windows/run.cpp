#include "min_shell.cpp"

int main() {
	min_shell shell;
	shell.run();
	return 0;
}
