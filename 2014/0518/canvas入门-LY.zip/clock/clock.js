
var context = document.getElementById('canvas').getContext('2d');
function draw() {
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    hour = hour >= 12 ? hour - 12 : hour;

    context.save();
    context.clearRect(0, 0, 1000, 1000);
    context.translate(500, 500);
    context.strokeStyle = "#000";
    context.fillStyle = "#000";
    context.lineCap = "round";
    context.lineWidth = 10;
    context.rotate(-Math.PI / 2)

    // write hour mark
    context.save();
    for (var i = 0; i < 12; i++) {
        context.beginPath();
        context.moveTo(320, 0);
        context.lineTo(400, 0);
        context.stroke();
        context.rotate(Math.PI / 6);
    }
    context.restore();

    //write minute mark
    context.save();
    context.lineWidth = 5;
    for (var i = 0; i < 60; i++) {
        if (i % 5 !== 0) {
            context.beginPath();
            context.moveTo(370, 0);
            context.lineTo(400, 0);
            context.stroke();
        }
        context.rotate(Math.PI / 30);
    }
    context.restore();

    context.save();
    context.beginPath();
    context.lineWidth = 35;
    context.rotate(hour * Math.PI / 6 + minute * Math.PI / 360 + second * Math.PI / 21600);
    context.moveTo(-50, 0);
    context.lineTo(200, 0);
    context.stroke();
    context.restore();

    context.save();
    context.beginPath();
    context.lineWidth = 20;
    context.rotate(minute * Math.PI / 30 + second * Math.PI / 1800);
    context.moveTo(-50, 0);
    context.lineTo(400, 0);
    context.stroke();
    context.restore();

    context.save();
    context.beginPath();
    context.fillStyle = "red";
    context.strokeStyle = "red";
    context.lineWidth = 5;
    context.rotate(Math.PI / 30 * second);
    context.moveTo(-100, 0);
    context.lineTo(435, 0);
    context.stroke();
    context.beginPath();
    context.arc(0, 0, 10, 0, 2 * Math.PI, true);
    context.fill();
    context.restore();

    context.lineWidth = 15;
    context.strokeStyle = "#325FA2";
    context.beginPath();
    context.arc(0, 0, 450, 0, 2 * Math.PI, true)
    context.stroke();

    context.restore();
    setTimeout(draw, 1000);
}

window.onload = function () {
    draw();
}