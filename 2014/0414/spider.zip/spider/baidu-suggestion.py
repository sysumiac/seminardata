# -*- coding=utf-8 -*-
import urllib2
import re

while True:
  keyword = raw_input('>> input your keyword: ')
  url = 'http://suggestion.baidu.com/su?wd=' + keyword + '&json=1&p=3&sid=4683_1424_5224_5848_4759_6018_5856_5918&cb=jQuery110202921781635377556_1397275701367&_=1397275701372'

  res = urllib2.urlopen(url)
  result = res.read()
  
  result = eval(re.search('\[.*?\]', result).group())

  print '..............................'
  for suggestion in result:
    print suggestion
  print '..............................\n\n'

