import urllib2

# url, data, headers定义

req = urllib2.Request(url, data, headers)
res = urllib2.open(req)
res.read()
