import urllib2
import re
import os

def get_pages_urls():
  url = 'http://baozoumanhua.com/duihua/hot/page/'
  for i in xrange(1, 800):
    yield url + str(i)

def get_pics_and_save(page):
  html = get_html(page)
  imgs_urls = parse_img_urls(html)
  for url in imgs_urls:
    save_img_by_url(url)

def get_html(page_url):
  return urllib2.urlopen(page_url).read()

def parse_img_urls(html):
  PIC_RE = '(?<=\<a\shref=\"\/articles\/)[\S\s]*?(?=\<\/a\>)'
  candidates = re.findall(PIC_RE, html)
  for candidate in candidates:
    result = re.search('(?<=src=\").*?(?=\")', candidate)
    if result:
      yield result.group()


page_count = 0
def save_img_by_url(url):
  global page_count
  page_count += 1

  file_name = str(page_count) + os.path.splitext(url)[1]
  img_file = file(file_name, 'wb')

  print 'downloading ' + file_name + ' ------'
  result = urllib2.urlopen(url).read()
  img_file.write(result)
  img_file.close()
  print 'done!-----------------------'

if __name__ == '__main__':
  for page in get_pages_urls():
    get_pics_and_save(page)
