import urllib2
import urllib

url = 'http://www.baidu.com'
data = urllib.urlencode({'name': 'Jerry'})
headers = {}

request = urllib2.Request(url, data, headers)
response = urllib2.urlopen(request)
print response.read()


