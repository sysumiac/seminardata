var calculatorState = 'power-off';
var expression = '';

window.onload = function() {
  addEventListenerToButtons();
}

function addEventListenerToButtons() {
  var buttons = document.getElementsByTagName('button');
  for(var i=0, length=buttons.length; i < length; i++) {
    var button = buttons[i];
    var eventHandler;
    switch (button.id) {
      case 'switch' :
        eventHandler = toggleCalculatorStateAndUpdateScreen;
        break;

      case 'clear' :
        eventHandler = clearExpressionAndUpdateScreen;
        break;

      case 'back' :
        eventHandler = stepBackAndUpdateScreen;
        break;

      case 'equal' :
        eventHandler = calculateExpressionAndUpdateScreen;
        break;

      default :
        eventHandler = addOperandToExpressionAndUpdateScreen;
        break;
    }

    button.addEventListener('click', eventHandler);
  }
}

function toggleCalculatorStateAndUpdateScreen() {
  if(calculatorState == 'power-off') {
    powerOn();
  } else {
    powerOff();
  }
}

function powerOn() {
  calculatorState = 'power-on';

  var calculator = document.getElementById('calculator');
  calculator.className = 'power-on';

  enableOperatingButtons();
}

function enableOperatingButtons() {
  var buttons = document.getElementsByTagName('button');
  for(var i=0, length=buttons.length; i < length; i++) {
    var button = buttons[i];
    if (button.id != 'switch') {
      button.removeAttribute('disabled');
    }
  }
}

function powerOff() {
  calculatorState = 'power-off';
  expression = '';

  var calculator = document.getElementById('calculator');
  calculator.className = 'power-off';

  disableOperatingButtons();
  updateScreen();
}

function disableOperatingButtons() {
  var buttons = document.getElementsByTagName('button');
  for(var i=0, length=buttons.length; i < length; i++) {
    var button = buttons[i];
    if (button.id != 'switch') {
      button.setAttribute('disabled', 'disabled');
    }
  }
}

function clearExpressionAndUpdateScreen() {
  expression = '';
  updateScreen();
}

function stepBackAndUpdateScreen() {
  if(expression.length > 0) {
    expression = expression.slice(0, -1);
    updateScreen();
  }
}

function addOperandToExpressionAndUpdateScreen(event) {
  expression += event.target.innerHTML;
  updateScreen();
}

function calculateExpressionAndUpdateScreen() {
  try {
    expression  = eval(expression);
  } catch(error) {
    showError();
  }

  updateScreen();
} 

function updateScreen() {
  document.getElementById('output').innerHTML = expression;
}

function showError() {
  alert('fuck! Invalid Expression!!!!!');
}